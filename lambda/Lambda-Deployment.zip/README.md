# Lambda Setup

1. Services > Lambda
1. Create Lambda Function
1. Author From Scratch
  - Function name: findybot
  - Runtime: Node.js 10.x
  - Permissions: create new role with basic permissions
1. Create

